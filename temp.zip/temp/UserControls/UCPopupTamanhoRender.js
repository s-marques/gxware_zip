function UCPopupTamanho($) {

	var template = '<UCPopupTamanho>';
	var partials = {  }; 
	Mustache.parse(template);
	var $container;
	this.show = function() {
			$container = $(this.getContainerControl());

			// Raise before show scripts


			//if (this.IsPostBack)
				this.setHtml(Mustache.render(template, this, partials));
			this.renderChildContainers();



			// Raise after show scripts
			this.afterShow(); 
	}

	this.Scripts = [];

		this.afterShow = function() {

				
			//	      if (window.location.href.indexOf('gxPopupLevel') > -1 && window.location.href.indexOf('promptexterno') == -1) {
			//            let width = parent.window.innerWidth - 140;
			//            let height = parent.window.innerHeight - 100;
			//            const popup = gx.popup.getPopup();
			//
			//            setTimeout(function () {
			//                const gxPopup = parent.document.getElementsByClassName('gx-popup');
			//                if (gxPopup.length > 0) {
			//                    const carregando = parent.document.getElementById('carregando');
			//                    if (carregando) {
			//                        carregando.innerHTML = '';
			//                    }
			//                }
			//                Array.from(gxPopup).forEach((e) => {
			//                    e.style.width = width + 'px';
			//                    e.style.height = height + 50 + 'px';
			//                });
			//            }, 100);
			//
			//            gx.fn.setCtrlProperty('LAYOUTMAINTABLE_MPAGE', 'Width', width);
			//            gx.fn.setCtrlProperty('LAYOUTMAINTABLE_MPAGE', 'Height', height);
			//
			//            gx.fn.setCtrlProperty('LAYOUTMAINTABLE', 'Width', width - 60);
			//            gx.fn.setCtrlProperty('LAYOUTMAINTABLE', 'Height', height - 50);
			//
			//            popup.autoresize = 0;
			//            popup.width = width;
			//            popup.height = height + 50;
			//
			//            if (frameElement?.style) {
			//                frameElement.style.width = width.toString() + 'px';
			//                frameElement.style.height = height.toString() + 'px';
			//            }
			//        }
					if(window.location.href.indexOf('gxPopupLevel') > -1 && window.location.href.indexOf('promptexterno') == -1)
					{
						const popup = gx.popup.getPopup();

						let width = parent.window.innerWidth ? parent.window.innerWidth : /* For non-IE */
			        	parent.document.documentElement ? parent.document.getElementsByTagName('body')[0].clientWidth : /* IE 6+ (Standards Compliant Mode) */
			            parent.document.body ? parent.document.body.clientWidth : /* IE 4 Compatible */
			            parent.window.screen.width; /* Others (It is not browser window size, but screen size) */
						

						let height = parent.window.innerHeight ? parent.window.innerHeight : /* For non-IE */
			        	parent.document.documentElement ? parent.document.getElementsByTagName('body')[0].clientHeight : /* IE 6+ (Standards Compliant Mode) */
			            parent.document.body ? parent.document.body.clientHeight : /* IE 4 Compatible */
			            window.screen.height; /* Others (It is not browser window size, but screen size) */
						
						width -= 140;
						height -= 100;
						
						setTimeout(function() { 
			 				window.parent.document.getElementsByClassName('gx-popup')[window.parent.document.getElementsByClassName('gx-popup').length - 1].style.top = '45px';
						}, 100);
						
						gx.fn.setCtrlProperty("LAYOUTMAINTABLE_MPAGE", "Width", width);
						gx.fn.setCtrlProperty("LAYOUTMAINTABLE_MPAGE", "Height", height);
						
						gx.fn.setCtrlProperty('LAYOUTMAINTABLE', 'Width', width - 60);
			            gx.fn.setCtrlProperty('LAYOUTMAINTABLE', 'Height', height - 50);
						
						popup.autoresize = 0;
			            popup.width = width;
			            popup.height = height + 50;
					}
				
		}



	this.autoToggleVisibility = true;

	var childContainers = {};
	this.renderChildContainers = function () {
		$container
			.find("[data-slot][data-parent='" + this.ContainerName + "']")
			.each((function (i, slot) {
				var $slot = $(slot),
					slotName = $slot.attr('data-slot'),
					slotContentEl;

				slotContentEl = childContainers[slotName];
				if (!slotContentEl) {				
					slotContentEl = this.getChildContainer(slotName)
					childContainers[slotName] = slotContentEl;
					slotContentEl.parentNode.removeChild(slotContentEl);
				}
				$slot.append(slotContentEl);
				$(slotContentEl).show();
			}).closure(this));
	};

}