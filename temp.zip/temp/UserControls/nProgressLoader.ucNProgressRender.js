function nProgressLoader_ucNProgress($) {
	 this.setloaderConfig = function(value) {
			this.loaderConfig = value;
		}

		this.getloaderConfig = function() {
			return this.loaderConfig;
		} 
	  

	var template = '<style>	/* Make clicks pass-through */	#nprogress {		pointer-events: none;	}	#nprogress .bar {		background:{{loaderColor}};		position: fixed;		z-index: 1031;		top: 0;		left: 0;				width: 100%;		height: 2px;	}		/* Fancy blur effect */	#nprogress .peg {		display: block;		position: absolute;		right: 0px;		width: 100px;		height: 100%;		box-shadow: 0 0 10px {{loaderColor}}, 0 0 5px {{loaderColor}};		opacity: 1.0;			-webkit-transform: rotate(3deg) translate(0px, -4px);			-ms-transform: rotate(3deg) translate(0px, -4px);				transform: rotate(3deg) translate(0px, -4px);	}	/* Remove these to get rid of the spinner */	#nprogress .spinner {		display: block;		position: fixed;		z-index: 1031;		top: 15px;		right: 15px;	}	#nprogress .spinner-icon {		width: 18px;		height: 18px;		box-sizing: border-box;			border: solid 2px transparent;		border-top-color: {{loaderColor}};		border-left-color: {{loaderColor}};		border-radius: 50%;				-webkit-animation: nprogress-spinner 400ms linear infinite;				animation: nprogress-spinner 400ms linear infinite;	}		.nprogress-custom-parent {		overflow: hidden;		position: relative;	}		.nprogress-custom-parent #nprogress .spinner,	.nprogress-custom-parent #nprogress .bar {		position: absolute;	}		@-webkit-keyframes nprogress-spinner {		0%   { -webkit-transform: rotate(0deg); }		100% { -webkit-transform: rotate(360deg); }	}		@keyframes nprogress-spinner {		0%   { transform: rotate(0deg); }		100% { transform: rotate(360deg); }	}			/* SCREEN LOADER */     .PopupBorder[style*=\"visibility: visible\"]+.loader {    		display: none	}	.loader {		position: fixed;		top: calc(50% - {{loaderSize}});		left: calc(50% - {{loaderSize}});		z-index: 1000;	}		.loader>div {		position: relative	}		.disc {		border-radius: 50%;		width: {{loaderSize}};		height: {{loaderSize}};		border: 25px solid {{loaderColor}};		border-top-color: #A9AFBB;		animation: spin 1s infinite linear	}		.disc-double {		border-style: double	}		.gradient {		width: {{loaderSize}};		height: {{loaderSize}};		position: relative	}		.gradient-img {		top: 0;		width: 100%;		height: 100%;		display: block;		position: absolute;	}		.gradient-spin {			box-sizing: border-box;		display: block;		position: absolute;		width: {{loaderSize}};		height: {{loaderSize}};		margin: 8px;		border: 8px solid {{loaderColor}};		border-radius: 50%;		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;		border-color: {{loaderColor}} transparent transparent transparent;	}		.pulse {		position: relative;		width: calc({{loaderSize}} * 0.20);		height: {{loaderSize}};		animation: pulse 1.25s infinite;		animation-delay: .41667s;		margin: 0 40px	}		.pulse:before,	.pulse:after {		content: \"\";		position: absolute;		display: block;		width: calc({{loaderSize}} * 0.20);		height: calc({{loaderSize}} * 0.75);		top: 50%;		transform: translateY(-50%);		animation: pulse 1.25s infinite	}		.pulse:before {		left: -40px	}		.pulse:after {		left: calc({{loaderSize}} * 0.40);		animation-delay: .83333s	}		.cube {		width: {{loaderSize}};		height: {{loaderSize}};		margin: 0 auto;		position: relative;		transform: rotateZ(45deg)	}		.cube-slice {		position: relative;		transform: rotateZ(45deg);		float: left;		width: 50%;		height: 50%;		position: relative;		transform: scale(1.1)	}		.cube-slice:before {		content: \"\";		position: absolute;		top: 0;		left: 0;		width: 100%;		height: 100%;		background-color: {{loaderColor}};		animation: cube-fold 2.76s infinite linear both;		transform-origin: 100% 100%	}		.cube-slice.slice2 {		transform: scale(1.1) rotateZ(90deg)	}		.cube-slice.slice2:before {		animation-delay: 0.35s	}		.cube-slice.slice3 {		transform: scale(1.1) rotateZ(180deg)	}		.cube-slice.slice3:before {		animation-delay: 0.69s	}		.cube-slice.slice4 {		transform: scale(1.1) rotateZ(270deg)	}		.cube-slice.slice4:before {		animation-delay: 1.04s	}		.modern {		left: calc(50% - 50px);		width: {{loaderSize}};		height: {{loaderSize}};		border-radius: 50%;		perspective: 780px	}		.modern-slice {		position: absolute;		width: 100%;		height: 100%;		box-sizing: border-box;		border-radius: 50%;		border-style: solid;		border-color: {{loaderColor}};		border-width: 0	}		.modern-slice.slice1 {		left: 0%;		top: 0%;		animation: modern-rotate-one 1.25s linear infinite;		border-bottom-width: 5px	}		.modern-slice.slice2 {		right: 0%;		top: 0%;		animation: modern-rotate-two 1.25s linear infinite;		border-right-width: 5px	}		.modern-slice.slice3 {		right: 0%;		bottom: 0%;		animation: modern-rotate-three 1.25s linear infinite;		border-top-width: 5px	}		@keyframes spin {		0% {			transform: rotate(0deg)		}			100% {			transform: rotate(360deg)		}	}		@keyframes pulse {		50% {			background: {{loaderColor}};		}	}		@keyframes cube-fold {			0%,		10% {			transform: perspective(136px) rotateX(-180deg);			opacity: 0		}			25%,		75% {			transform: perspective(136px) rotateX(0deg);			opacity: 1		}			90%,		100% {			transform: perspective(136px) rotateY(180deg);			opacity: 0		}	}		@keyframes modern-rotate-one {		0% {			transform: rotateX(35deg) rotateY(-45deg) rotateZ(0deg)		}			100% {			transform: rotateX(35deg) rotateY(-45deg) rotateZ(360deg)		}	}		@keyframes modern-rotate-two {		0% {			transform: rotateX(50deg) rotateY(10deg) rotateZ(0deg)		}			100% {			transform: rotateX(50deg) rotateY(10deg) rotateZ(360deg)		}	}		@keyframes modern-rotate-three {		0% {			transform: rotateX(35deg) rotateY(55deg) rotateZ(0deg)		}			100% {			transform: rotateX(35deg) rotateY(55deg) rotateZ(360deg)		}	}			@keyframes lds-ring {		0% {			transform: rotate(0deg);		}		100% {			transform: rotate(360deg);		}	}		</style>';
	var partials = {  }; 
	Mustache.parse(template);
	var $container;
	this.show = function() {
			$container = $(this.getContainerControl());

			// Raise before show scripts
			this.before(); 


			//if (this.IsPostBack)
				this.setHtml(Mustache.render(template, this, partials));
			this.renderChildContainers();



			// Raise after show scripts
			this.after(); 
	}

	this.Scripts = [];

		this.after = function() {

				
					const myThis 			= this;
					myThis.isDone 			= false;
					myThis.TotalProgress 	= 0;
					myThis.Progress 		= 0;
					
					let loaderConfig = myThis.loaderConfig;
					myThis.loaderSize = loaderConfig.ScreenLoader.loaderSize;
					myThis.loaderColor = loaderConfig.loaderColor;
				
					//SETA AS CONFIGURAÇÕES DO NPROGRESS DE ACORDO COM OS VALORES QUE VEM DO SDT DE CONFIGURAÇÕES{sdtNProgressConfigs}
					if(myThis.loaderType !== "2"){     
						NProgress.configure({ barSelector: loaderConfig.ProgressBar.barSelector });
						NProgress.configure({ easing: loaderConfig.ProgressBar.easing }); 
						NProgress.configure({ minimum: parseFloat(loaderConfig.ProgressBar.minimum) });
						NProgress.configure({ parent: loaderConfig.ProgressBar.parent });
						NProgress.configure({ positionUsing: loaderConfig.ProgressBar.positionUsing });
						NProgress.configure({ showSpinner: loaderConfig.ProgressBar.showSpinner });
						NProgress.configure({ speed: loaderConfig.ProgressBar.speed });
						NProgress.configure({ spinnerSelector: loaderConfig.ProgressBar.spinnerSelector });
						NProgress.configure({ template: loaderConfig.ProgressBar.template });
						NProgress.configure({ trickle: loaderConfig.ProgressBar.trickle });
						NProgress.configure({ trickleSpeed: loaderConfig.ProgressBar.trickleSpeed });
					};
					
					/* SCREEN LOADER */
					
					//começo removendo os listeners
					if (!myThis.IsPostBack){
					/*LOADER MODEL*/
					
						myThis.modelosLoaderMask = ['<div class="gradient"><div class="gradient-img"></div><div class="gradient-spin"></div></div>',
												'<div class="disc"></div>',
												'<div class="disc disc-double"></div>',
												'<div class="pulse"></div>',
												'<div class="cube"><div class="cube-slice slice1"></div><div class="cube-slice slice2"></div><div class="cube-slice slice4"></div><div class="cube-slice slice3"></div></div>',
												'<div class="modern"><div class="modern-slice slice1"></div><div class="modern-slice slice2"></div><div class="modern-slice slice3"></div></div>'
						]
						
						document.removeEventListener("DOMNodeInserted", () => {}, true);
						document.removeEventListener("DOMNodeRemoved", () => {}, true);
						
						gx.spa.deleteObserver("onbeforesend");
						gx.spa.deleteObserver("onnavigatestart");
						gx.spa.deleteObserver("onbeforeprocessresponse");
						gx.spa.deleteObserver("oncontentreplace");
						gx.spa.deleteObserver("onnavigate");
						
						// Configurar MutationObserver
						const observer = new MutationObserver((mutationsList) => {
							for (let mutation of mutationsList) {
								if (mutation.type === 'childList') {
									mutation.addedNodes.forEach((node) => {
										if (node.nodeType === 1 && node.classList.contains("gx-mask")) {
											if (!document.querySelector(".loader")) {
												if (myThis.loaderType === "1" || myThis.loaderType === "3") {
													NProgress.start();
												}
												if (myThis.loaderType === "2" || myThis.loaderType === "3") {
													jQuery("body").append(
														`<div class="loader"> ${
															myThis.modelosLoaderMask[loaderConfig.ScreenLoader.loaderStyle]
														}</div>`
													);
												}
											}
										}
									});
						
									mutation.removedNodes.forEach((node) => {
										if (node.nodeType === 1 && node.classList.contains("gx-mask")) {
											if (myThis.loaderType !== "2") {
												NProgress.done();
											}
											if (myThis.loaderType !== "1" && document.querySelector(".loader")) {
												document.querySelector(".loader").remove();
											}
										}
									});
								}
							}
						});
						
						// Observar mudanças no body
						observer.observe(document.body, { childList: true, subtree: true });

					/* SCREEN LOADER */
										
					/* -- 5 PASSOS DO INÍCIO DA REQUISIÇÃO ATÉ O CARREGAMENTO DA PÁGINA */
						//STEP 1
						gx.spa.addObserver('onbeforesend', this, ()=>{
							
							switch (myThis.loaderType){
								case "1":
									//PROGRESSBAR
									NProgress.start();
									break;
								case "2":
									//SCREENLOADER
									if (!document.querySelector(".loader")){
										jQuery("body").append(
											`<div class="loader"> ${
											myThis.modelosLoaderMask[loaderConfig.ScreenLoader.loaderStyle]
											}</div>`
										);				
				
									};
									break;
								default:
									//AMBOS 
									NProgress.start();
									if (!document.querySelector(".loader")){
										jQuery("body").append(
										`<div class="loader"> ${
											myThis.modelosLoaderMask[loaderConfig.ScreenLoader.loaderStyle]
										}</div>`
										);						
									};
									break;
							};
						}, {single:false});
					
						if(myThis.loaderType !== '2'){
							//STEP 2
							gx.spa.addObserver('onnavigatestart', this, ()=>{
								
								myThis.Progress = 0.3;
							}, {single:false});
							
							//STEP 3
							gx.spa.addObserver('onbeforeprocessresponse', this, ()=>{
								
								myThis.Progress = 0.3;
							}, {single:false});
							
							//STEP 4
							gx.spa.addObserver('oncontentreplace', this, ()=>{
								
								myThis.Progress = 0.4;
							}, {single:false});
						}
					
						//STEP 5
						gx.spa.addObserver('onnavigate', this, ()=>{
							
							switch (myThis.loaderType){
								case "1":
									//PROGRESSBAR
									myThis.Progress = 1;
									break;
								case "2":
									//SCREENLOADER
									if (document.querySelector(".loader")){					
										document.querySelector(".loader").remove()
									};
									break;
								default:
									//AMBOS 
									myThis.Progress = 1;
									if (document.querySelector(".loader")){					
										document.querySelector(".loader").remove()
									};
									break;
							};
						}, {single:false});
						
						if(myThis.loaderType !== "2"){
							//eventos de browser.
							NProgress.start();
							NProgress.inc(0.9);
							
							setTimeout(()=>{
								NProgress.done();
								NProgress.remove();
							},1000)			
						}
					}else{
						//eventos genexus
						waitLoaderComplete()	
					}
					

					function waitLoaderComplete(){
						setTimeout(() => {
							if (myThis.TotalProgress >= 1){
								loadComplete();
							}else{
								callback()
								waitLoaderComplete()
							}
						}, 300)
					}

					function loadComplete(){
						NProgress.done(true);
						NProgress.remove();
						myThis.TotalProgress = 0;
						myThis.Progress = 0;
					}

					const callback = () => {
						if (myThis.Progress && myThis.Progress != 0){
							myThis.TotalProgress += myThis.Progress
							NProgress.inc(myThis.Progress)
							myThis.Progress 		= 0;
						}
					}					
				

				
		}
		this.before = function() {

				
					this.loaderSize  = this.loaderConfig.ScreenLoader.loaderSize;
					this.loaderColor = this.loaderConfig.loaderColor;
					
					if (!this.IsPostBack){
						
						if (!window.NProgress){
							this._loadScriptByUrl("Resources/NProgressLoader/nprogress.js")				
							window.NProgress = NProgress;
							this.nprogress = NProgress;
						}
					}
				
		}
		this.InsertLoader = function() {


					const myThis = this;
					if (!document.querySelector(".loader")){
							document.body.innerHTML += `<div class="loader"> ${myThis.modelosLoaderMask[myThis.loaderConfig.ScreenLoader.loaderStyle]}</div>`		
					};
					
				
		}
		this.RemoveLoader = function() {

					if (document.querySelector(".loader")){					
							document.querySelector(".loader").remove()
					}	
				
		}
		this._getStaticPath = function() {

					const gxStaticDir = gx.staticDirectory.substring(1, gx.staticDirectory.length)
					const staticDir = (gxStaticDir !== ""? "../":"") + gxStaticDir		
					return staticDir + (staticDir !== ""? "/":"");			
				
		}
		this._loadScriptByUrl = function(url ) {

					const scriptUrl = location.protocol + "//" + location.host + "/" + gx.basePath + "/" + gx.staticDirectory + url//"Resources/TinyMCE/scripts/tinymce.min.js"
					$.ajax({
						async: false,
						url: scriptUrl,
						dataType: "script"
					});	
				
		}



	this.autoToggleVisibility = true;

	var childContainers = {};
	this.renderChildContainers = function () {
		$container
			.find("[data-slot][data-parent='" + this.ContainerName + "']")
			.each((function (i, slot) {
				var $slot = $(slot),
					slotName = $slot.attr('data-slot'),
					slotContentEl;

				slotContentEl = childContainers[slotName];
				if (!slotContentEl) {				
					slotContentEl = this.getChildContainer(slotName)
					childContainers[slotName] = slotContentEl;
					slotContentEl.parentNode.removeChild(slotContentEl);
				}
				$slot.append(slotContentEl);
				$(slotContentEl).show();
			}).closure(this));
	};

}